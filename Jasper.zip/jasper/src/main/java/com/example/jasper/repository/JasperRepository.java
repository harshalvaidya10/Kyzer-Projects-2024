package com.example.jasper.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.jasper.model.Jasper;

public interface JasperRepository extends JpaRepository<Jasper, Integer>{

}
