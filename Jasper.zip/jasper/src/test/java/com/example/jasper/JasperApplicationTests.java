package com.example.jasper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JasperApplicationTests {

	@Test
	void contextLoads() {
	}

}
