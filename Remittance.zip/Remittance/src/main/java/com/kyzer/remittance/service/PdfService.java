package com.kyzer.remittance.service;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

@Service
public class PdfService {
	public void createPdfFromJsonObjects(List<JSONObject> jsonObjects) {
		try {
			for (int i = 0; i < jsonObjects.size(); i++) {
				JSONObject jsonObject = jsonObjects.get(i);

				// Create a new document
				Document document = new Document();
				document.setPageSize(PageSize.A4);
				PdfWriter.getInstance(document, new FileOutputStream(jsonObject.optString("collectionId")+".pdf"));
				document.open();

				// Add content to the PDF
				addContent(document, jsonObject);

				// Close the document
				document.close();
			}
		} catch (DocumentException | FileNotFoundException e) {
			e.printStackTrace();
			// Handle exception
		}
	}

	private void addContent(Document document, JSONObject jsonObject) throws DocumentException {
		
		Font font = FontFactory.getFont(FontFactory.COURIER, 9);
		
//		Paragraph 1
		String para1 = "RBL Bank Ltd";
		Paragraph paragraph1 = new Paragraph(para1, font);
		paragraph1.setAlignment(Element.ALIGN_CENTER);
		document.add(paragraph1);
		
//		Paragraph 2
		String para2 = "Branch: "+jsonObject.optString("brName")+"\n"
					+ "Place: "+jsonObject.optString("brAddress1")+"\n"
					+ jsonObject.optString("brAddress2")+"\n"
					+ jsonObject.optString("brAddress3")+"\n"
					+ jsonObject.optString("brCity")+"\n"
					+ jsonObject.optString("brState")+"\n";
		Paragraph paragraph2 = new Paragraph(para2, font);
		paragraph2.setAlignment(Element.ALIGN_LEFT);
		document.add(paragraph2);
		
		Paragraph dash = new Paragraph("----------------------------------------------------------------------------------------------------------------------------------");
		dash.setAlignment(Element.ALIGN_CENTER);
		document.add(dash);
		
//		Paragraph 3
		String para3 = "Category: Banking and Financial Services";
		Paragraph paragraph3 = new Paragraph(para3, font);
		paragraph3.setAlignment(Element.ALIGN_CENTER);
		document.add(paragraph3);
		
		dash.setAlignment(Element.ALIGN_CENTER);
		document.add(dash);
		
//		Paragraph 4
		if(jsonObject.optString("inOutInd").equals("O")) {
			String para4 = "Debit Advice for Outward Remittance";
			Paragraph paragraph4 = new Paragraph(para4, font);
			paragraph4.setAlignment(Element.ALIGN_CENTER);
			document.add(paragraph4);
		}
		else {
			String para4 = "Credit Advice for Inward Remittance";
			Paragraph paragraph4 = new Paragraph(para4, font);
			paragraph4.setAlignment(Element.ALIGN_CENTER);
			document.add(paragraph4);
		}
		
		
//		Paragraph 5
		String para5 = "Dated: "+jsonObject.optString("lodgeDate");
		Paragraph paragraph5 = new Paragraph(para5, font);
		paragraph5.setAlignment(Element.ALIGN_RIGHT);
		document.add(paragraph5);
		
//		Paragraph 6
		
		if(jsonObject.optString("inOutInd").equals("O")) {
			String para6 = "From,\n"
					+jsonObject.optString("partyName")+"\n"
					+jsonObject.optString("partyAddress1")+"\n"
					+ jsonObject.optString("partyAddress2")+"\n"
					+ jsonObject.optString("partyAddress3")+"\n"
					+ jsonObject.optString("partyCity")+" "+jsonObject.optString("partyState")+" "+jsonObject.optString("partyPinCode")+"\n"
					+ "We hereby debited your account as detailed below"+"\n"
					+ "Our Reference Number : "+jsonObject.optString("collectionId")+"\n";
					
			Paragraph paragraph6 = new Paragraph(para6, font);
			paragraph6.setAlignment(Element.ALIGN_LEFT);
			document.add(paragraph6);
		}
		else {
			String para6 = "To,\n"
					+jsonObject.optString("partyName")+"\n"
					+jsonObject.optString("partyAddress1")+"\n"
					+ jsonObject.optString("partyAddress2")+"\n"
					+ jsonObject.optString("partyAddress3")+"\n"
					+ jsonObject.optString("partyCity")+" "+jsonObject.optString("partyState")+" "+jsonObject.optString("partyPinCode")+"\n"
					+ "We hereby credited your account as detailed below"+"\n"
					+ "Our Reference Number : "+jsonObject.optString("collectionId")+"\n";
			Paragraph paragraph6 = new Paragraph(para6, font);
			paragraph6.setAlignment(Element.ALIGN_LEFT);
			document.add(paragraph6);
		}
		
		
//		Paragraph 7
		String para7 = "Dated: "+jsonObject.optString("valueDate");
		Paragraph paragraph7 = new Paragraph(para7, font);
		paragraph7.setAlignment(Element.ALIGN_RIGHT);
		document.add(paragraph7);
		
//		Paragraph 8
		if(jsonObject.optString("inOutInd").equals("O")) {
			String para8 = "Beneficiary Details\n"
					+ "Name: "+jsonObject.optString("otherPartyName")+"\n"
					+ "Address: "+jsonObject.optString("otherPartyAddress1")+"\n"
					+ jsonObject.optString("otherPartyAddress2")+"\n"
					+ jsonObject.optString("otherPartyAddress3")+"\n"
					+ "Purpose Code: "+jsonObject.optString("purposeCode")+" - " +jsonObject.optString("purposeCodeDesc")+"\n";
			
			Paragraph paragraph8 = new Paragraph(para8, font);
			paragraph8.setAlignment(Element.ALIGN_LEFT);
			document.add(paragraph8);
		}
		else {
			String para8 = "Remitter Details\n"
					+ "Name: "+jsonObject.optString("otherPartyName")+"\n"
					+ "Address: "+jsonObject.optString("otherPartyAddress1")+"\n"
					+ jsonObject.optString("otherPartyAddress2")+"\n"
					+ jsonObject.optString("otherPartyAddress3")+"\n"
					+ "Purpose Code: "+jsonObject.optString("purposeCode")+" - " +jsonObject.optString("purposeCodeDesc")+"\n";
			
			Paragraph paragraph8 = new Paragraph(para8, font);
			paragraph8.setAlignment(Element.ALIGN_LEFT);
			document.add(paragraph8);
		}
		
		dash.setAlignment(Element.ALIGN_CENTER);
		document.add(dash);
		
//		Creating PDF Table
        PdfPTable table = new PdfPTable(4);
        table.setWidthPercentage(100);
		table.setWidths(new float[] { 180f, 40f, 40f, 80f});
		table.getDefaultCell().setBorderWidth(0);
		
//		Creating headers
		 String[] headers = {"Transaction Particulars", "Rate", "Currency", "Amount"};
		 
		 for (String header : headers) {
	        	
	            PdfPCell cell = new PdfPCell(new Paragraph(header, font));
	            cell.setHorizontalAlignment(Element.ALIGN_LEFT);
	            cell.setBorder(Rectangle.NO_BORDER);
	            table.addCell(cell);
	        }
		 
		 document.add(table);
		 
		 dash.setAlignment(Element.ALIGN_CENTER);
		 document.add(dash);
		 

	}
}
