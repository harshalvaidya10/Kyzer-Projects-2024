
package com.kyzer.remittance.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.kyzer.remittance.model.TransactionData;

@Repository
public interface TransactionRepository extends JpaRepository<TransactionData, Integer>{
	
	List<TransactionData> findAllByOrderByCollectionIDAsc();
	
}


//Repository - List<TransactionData> findAllByCollectionID(String collection_id);