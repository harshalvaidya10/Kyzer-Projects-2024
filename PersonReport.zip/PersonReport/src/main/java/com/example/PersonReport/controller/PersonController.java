package com.example.PersonReport.controller;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.PersonReport.service.PersonService;

import net.sf.jasperreports.engine.JRException;

@RestController
public class PersonController {

    @Autowired
    private PersonService personService;

    @GetMapping("/generate")
    public String generateReport(@RequestParam(value = "columns") List<String> columns) throws JRException {
    	
        List<Boolean> flags = personService.setFlags(columns);
        String message = personService.generateReport(flags);
        return message;
    }
    
}
