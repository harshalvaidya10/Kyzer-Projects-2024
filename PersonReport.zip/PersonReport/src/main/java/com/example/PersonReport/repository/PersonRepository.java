package com.example.PersonReport.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.PersonReport.model.Persons;

@Repository
public interface PersonRepository extends JpaRepository<Persons, Integer>{

}
