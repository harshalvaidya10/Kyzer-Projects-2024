package com.example.PersonReport;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersonReportApplication {

	public static void main(String[] args) {
		SpringApplication.run(PersonReportApplication.class, args);
	}

}
