package com.example.PersonReport.service;



import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.PersonReport.model.Persons;
import com.example.PersonReport.repository.PersonRepository;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

@Service
public class PersonService {

	@Autowired
	private PersonRepository repository;

	//method for setting flags for required columns
	public List<Boolean> setFlags(List<String> fields) {

		
		
		//declare flags for each columns
		boolean showId = false;
		boolean showFirstName = false;
		boolean showMiddleName = false;
		boolean showLastName = false;
		boolean showAge = false;
		boolean showGender = false;
		boolean showIncome = false;

		//list --> stores flags 
		List<Boolean> flags = new ArrayList<>();

		//setting flags for required columns
		// setting flags for required columns
		for (int i = 0; i < fields.size(); i++) {
		    String field = fields.get(i);
		    if (field.equals("Id")) {
		        showId = true;
		    } else if (field.equals("First Name")) {
		        showFirstName = true;
		    } else if (field.equals("Middle Name")) {
		        showMiddleName = true;
		    } else if (field.equals("Last Name")) {
		        showLastName = true;
		    } else if (field.equals("Age")) {
		        showAge = true;
		    } else if (field.equals("Gender")) {
		        showGender = true;
		    } else if (field.equals("Income")) {
		        showIncome = true;
		    }
		}

		
		//add flags in list
		flags.add(showId);
		flags.add(showFirstName);
		flags.add(showMiddleName);
		flags.add(showLastName);
		flags.add(showAge);
		flags.add(showGender);
		flags.add(showIncome);
		
		return flags;

	}
	
	//method for generating report
	public String generateReport(List<Boolean> flags) throws JRException {
		
		//compiling JRXML File
		String jrxmlFilePath = "C:\\Users\\Kyzer\\Desktop\\Harshal Kyzer\\PersonReport\\src\\main\\resources\\static\\PersonReport.jrxml";
		JasperReport report = JasperCompileManager.compileReport(jrxmlFilePath);
	
		
		//setting up parameters
		Map<String, Object> parameters = new HashMap<>();
		parameters.put("showId", flags.get(0));
		parameters.put("showFirstName", flags.get(1));
		parameters.put("showMiddleName", flags.get(2));
		parameters.put("showLastName", flags.get(3));
		parameters.put("showAge", flags.get(4));
		parameters.put("showGender", flags.get(5));
		parameters.put("showIncome", flags.get(6));
		
		//adding Data Source in Jasper
		List<Persons> personsData = repository.findAll();
		JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(personsData);
		
		//filling Jasper Report
		JasperPrint print = JasperFillManager.fillReport(report, parameters, dataSource);
		
		//exporting the report in pdf
		String pdfPath = "C:\\Users\\Kyzer\\Desktop\\Harshal Kyzer\\PersonReport\\src\\main\\resources\\static\\Report.pdf";
		JasperExportManager.exportReportToPdfFile(print, pdfPath);

		return "Report generated successfully...";
	}
}
